def fun(a):
    s = a+" word"
    print(s)




if __name__ == '__main__':
    fun("hello")
